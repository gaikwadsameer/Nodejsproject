const sql = require("msnodesqlv8");

const connectionstring = "server=DESKTOP-MJQF0IH;database=testdb;trusted_connection=yes;driver={sql servr native client 11.0}";
const query = "select * from clients";

sql.query(connectionstring, query, (err, rows) => {
    console.log(rows);
});